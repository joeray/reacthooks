const checkoutData = {
    products: [],
    items: 0,
    price: 0,
    discounts: [
        { name: '2-for-1', title: '2x1 Mug offer', count: 0 },
        { name: 'bulk', title: 'x3 Shirt offer', count: 0 },
        { name: 'Promo', title: 'Promo code', count: 0 },
    ],
    totalPrice: 0,
}

export default checkoutData
